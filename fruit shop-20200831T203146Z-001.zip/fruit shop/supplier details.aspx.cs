﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class _Default : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection("Data Source=.\\SQLEXPRESS; Initial Catalog=fruit_shop; integrated Security=true;");
    SqlCommand cmd1 = new SqlCommand();
    SqlDataReader reader = null;
    
    long sid;
    //string time = String.Format("{0:HH:mm:ss}", DateTime.Now);
    string time = DateTime.Now.ToString("HH:mm:ss");
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            SqlDataAdapter ad = new SqlDataAdapter("select product_name from new_products_entry", con);
            DataTable dt = new DataTable();
            ad.Fill(dt);
            DropDownList1.DataSource = dt;
            DropDownList1.DataBind();
            DropDownList1.DataTextField = "product_name";
            DropDownList1.DataBind();
        }
    }
    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("home.aspx");
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        int q;
        q = Convert.ToInt32(TextBox4.Text);
        int kg;
        SqlDataAdapter ad = new SqlDataAdapter("select max(sid) from supplier_details_entry", con);
        DataTable dt = new DataTable();
        ad.Fill(dt);
        if (dt.Rows.Count > 0)
        {
            if (dt.Rows[0][0].ToString() == "")
            {
                sid = 10001;
            }
            else
            {
                sid = Convert.ToInt32(dt.Rows[0][0].ToString()) + 1;
            
            } 

        }


      

        SqlCommand cmd = new SqlCommand("insert into supplier_details_entry(sid,supplier_name,place,product_name,quantity,mrp,rate,mobile_no,mail_id,date,time) values('"+sid+"','" + TextBox1.Text + "','" + TextBox2.Text + "','" +DropDownList1.SelectedValue+ "','" +TextBox4.Text + "','" + TextBox8.Text + "','" + TextBox7.Text + "','" + TextBox5.Text + "','" + TextBox6.Text + "',getdate(),'"+time+"')", con);
        con.Open();
        cmd.ExecuteNonQuery();
        con.Close();
        Page.RegisterStartupScript("msg", "<script>alert('Your Details Saved Successfully')</script>");
        TextBox1.Text = "";
        TextBox2.Text = "";
        TextBox4.Text = "";
        TextBox5.Text = "";
        TextBox6.Text = "";
        TextBox7.Text = "";
        TextBox8.Text = "";

       
        string quan = "select kg from stock_details where product_name='"+DropDownList1.SelectedValue+"'";
        SqlDataAdapter ad3 = new SqlDataAdapter(quan,con);
        DataSet ds = new DataSet();
        ad3.Fill(ds);

       // Label17.Text = ds.Tables[0].Rows[0][0].ToString();
        int quantity =Convert.ToInt32( ds.Tables[0].Rows[0][0].ToString());

        kg = q+ quantity;
        SqlDataAdapter ad2 = new SqlDataAdapter("update stock_details set kg='"+kg+"' where product_name='"+DropDownList1.SelectedValue+"'",con);
        DataTable dt2 = new DataTable();
        ad2.Fill(dt2);
       

      
    }
    


    protected void Button1_Click(object sender, EventArgs e)
    {
        TextBox1.Text = "";
        TextBox2.Text = "";
        TextBox4.Text = "";
        TextBox5.Text = "";
        TextBox6.Text = "";
        TextBox7.Text = "";
        TextBox8.Text = ""; 
        
    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }


    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {

    }
    
    protected void Button3_Click1(object sender, EventArgs e)
    {
        Response.Redirect("new_products.aspx");
    }
}


//int quantity ;
//quantity = Convert.ToInt32("select kg from stock_detail");
//SqlCommand cmd1 = new SqlCommand("select kg from stock_details",con);
//con.Open();
//int quantity = (int)cmd1.ExecuteScalar();

//string quan = "select kg from stock_detail";

//int quantity = Convert.ToInt32(quan);

//con.Open();
//cmd1.Connection = con;
//cmd1.CommandText = "select kg from stock_details";
//int quantity = (int)cmd1.ExecuteNonQuery();
//con.Close();

//SqlCommand cmd2 = new SqlCommand("select kg from stock_details");
//con.Open();
//int quantity = (int)cmd2.ExecuteNonQuery();
//con.Close();

//string str = "select kg from stock_details;
//con.Open();
//SqlCommand cmd2 = new SqlCommand(str,con);
//int quantity = cmd2.ExecuteNonQuery();
//return (int)quantity;

//kg = q + quantity;