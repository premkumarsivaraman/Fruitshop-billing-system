﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class _Default : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection("Data Source = .\\SQLEXPRESS; Initial Catalog = fruit_shop; integrated security = true;");

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
                    

        con.Open();
        SqlCommand cmd = new SqlCommand("select *from stock_details",con);
        SqlDataReader rdr = cmd.ExecuteReader();
        GridView1.DataSource=rdr;
        GridView1.DataBind();
        con.Close();
         }
    }


    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("home.aspx");
    }
}



            //SqlDataAdapter ad = new SqlDataAdapter("select fruit_name from supplier_detail_entry", con);
            //DataTable dt = new DataTable();
            //ad.Fill(dt);
            //if (dt.Rows.Count > 0)
            //{
            //    for (int i = 0; i < dt.Rows.Count; i++)
            //    {
            //        DataRow dr = dt.NewRow();
            //        dr["fruit_name"] = dt.Rows[i][0];
            //    }
            //    GridView1.DataSource = dt;
            //    GridView1.DataBind();











        //SqlDataAdapter ad1 = new SqlDataAdapter("select fruit_name from supplier_detail_entry", con);
        //DataTable dt1 = new DataTable();
        //ad1.Fill(dt1);
        //if (dt1.Rows.Count > 0)
        //{
        //    for (int i = 0; i < dt1.Rows.Count; i++)
        //    {
        //        DataRow dr = dt1.NewRow();
        //        dr["item"] = dt1.Rows[i][0];
        //        dr["rate"] = dt1.Rows[i][0].ToString();
        //        dt1.Rows.Add(dr);
        //    }
        //    GridView1.DataSource = dt1;
        //    GridView1.DataBind();
        //}
           






        //SqlDataAdapter ad = new SqlDataAdapter("");
        //DataTable dt = new DataTable();
        //ad.Fill(dt);
        //if (dt.Rows.Count > 0)
        //{
        //    DataTable dt1 = new DataTable();
        //    dt1.Columns.Add("item");
        //    dt1.Columns.Add("rate");
        //}

    
