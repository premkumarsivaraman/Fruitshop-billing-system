﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Text;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;

public partial class _Default : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection("Data Source = .\\SQLEXPRESS; Initial Catalog = fruit_shop; integrated security = true;");
    int bill_no;
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack)
        {
            SqlDataAdapter ad = new SqlDataAdapter("select product_name from stock_details", con);
            DataTable dt = new DataTable();
            ad.Fill(dt);
            DropDownList1.DataSource = dt;
            DropDownList1.DataBind();
            DropDownList1.DataTextField = "product_name";
            DropDownList1.DataBind();
        }
        
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        int rate;
        int amount= Convert.ToInt32(TextBox1.Text);
        int purchase_kg = Convert.ToInt32(TextBox1.Text);
        int total;
        int pid;

        string product_id = "select pid from new_products_entry where product_name='" + DropDownList1.SelectedValue + "'";
        SqlDataAdapter ad2 = new SqlDataAdapter(product_id, con);
        DataSet ds2 = new DataSet();
        ad2.Fill(ds2);
        pid = Convert.ToInt32(ds2.Tables[0].Rows[0][0].ToString());

        string rate_1 = "select mrp from supplier_details_entry where product_name='" + DropDownList1.Text + "'";
        SqlDataAdapter ad1 = new SqlDataAdapter(rate_1,con);
        DataSet ds1 = new DataSet();
        ad1.Fill(ds1);
        rate = Convert.ToInt32(ds1.Tables[0].Rows[0][0].ToString());
        total = rate * amount;

        SqlCommand cmd1 = new SqlCommand("insert into bill_box (pid,product_name,quantity,rate,total)values('"+pid+"','"+DropDownList1.SelectedValue+"','"+purchase_kg+"','"+rate+"','"+total+"')",con);
        con.Open();
        cmd1.ExecuteNonQuery();
        con.Close();
        TextBox1.Text = "";

        //update into stock details
        SqlDataAdapter ad3 = new SqlDataAdapter("select kg from stock_details where product_name='" + DropDownList1.SelectedValue + "'", con);
        DataSet ds3 = new DataSet();
        ad3.Fill(ds3);
        
        int stock_kg = Convert.ToInt32(ds3.Tables[0].Rows[0][0].ToString());
        int up_kg;
        up_kg = stock_kg - purchase_kg;
        SqlDataAdapter ad4 = new SqlDataAdapter("update stock_details set kg = '" + up_kg + "' where product_name='" + DropDownList1.SelectedValue + "'", con);
        DataTable dt4 = new DataTable();
        ad4.Fill(dt4);
    }


    public string getWhileLoopData()
    {
        string htmlStr = "";


        SqlCommand thisCommand = con.CreateCommand();
        thisCommand.CommandText = "SELECT * from bill_box";
        con.Open();
        SqlDataReader reader = thisCommand.ExecuteReader();

        while (reader.Read())
        {

          //  Debug.Indent(); Debug.WriteLine(reader.GetValue(0));

           // int pid =  reader.GetInt32(0);
            int pid = Convert.ToInt16(reader.GetValue(0));

            string product_name = reader.GetString(1);
            int quantity = reader.GetInt32(2);
            int rate = reader.GetInt32(3);
            int total = Convert.ToInt16(reader.GetValue(4));
            htmlStr += "<tr><td>" + pid + "</td><td>"+ product_name +"</td><td>" + quantity + "</td><td>"+ rate +"</td><td>" + total + "</td></tr>";

        }

        con.Close();
        string str = "select sum(total) from bill_box";
        SqlDataAdapter dat = new SqlDataAdapter(str, con);
        DataSet ds = new DataSet();
        dat.Fill(ds);
        Label3.Text = ds.Tables[0].Rows[0][0].ToString();

        return htmlStr;

       
        

       
    }


    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("home.aspx");
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        string bill = "cid";
        string time = DateTime.Now.ToString("HH:mm:ss");
       
         SqlDataAdapter ad = new SqlDataAdapter("select max(bill_no) from bill_backup", con);
        DataTable dt = new DataTable();
        ad.Fill(dt);
        if (dt.Rows.Count > 0)
        {
            if (dt.Rows[0][0].ToString() == "")
            {
                bill_no = 10001;
            }
            else
            {
                bill_no = Convert.ToInt32(dt.Rows[0][0].ToString()) + 1;
            
            } 

        }

        SqlDataAdapter ad3 = new SqlDataAdapter("select sum(total) from bill_box",con);
        DataSet ds3 = new DataSet();
        ad3.Fill(ds3);

        int grand_total = Convert.ToInt32(ds3.Tables[0].Rows[0][0].ToString());


        SqlCommand cmd2 = new SqlCommand("insert into bill_backup(bill,bill_no,date,time,total) values ('"+bill+"','"+bill_no+"',getdate(),'"+time+"','"+grand_total+"')",con);
        con.Open();
        cmd2.ExecuteNonQuery();
        con.Close();
        Response.Redirect("bill.aspx");

    }

    protected void Button4_Click(object sender, EventArgs e)
    {
        SqlDataAdapter ad5 = new SqlDataAdapter("truncate table bill_box",con);
        DataSet ds5 = new DataSet();
        ad5.Fill(ds5);
    }
}