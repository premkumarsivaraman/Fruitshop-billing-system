﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class _Default : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection("Data Source=.\\SQLEXPRESS; Initial Catalog=fruit_shop; integrated Security=true;");
    int pid;
    int temp_kg = 0;
    
   
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string product_name = TextBox1.Text;
        SqlDataAdapter ad = new SqlDataAdapter("select max(pid) from new_products_entry", con);
        DataTable dt = new DataTable();
        ad.Fill(dt);
        if (dt.Rows.Count > 0)
        {
            if (dt.Rows[0][0].ToString() == "")
            {
                pid = 1001;
            }
            else
            {
                pid = Convert.ToInt32(dt.Rows[0][0].ToString()) + 1;
            
            } 

        }

        SqlCommand cmd = new SqlCommand("insert into new_products_entry(pid,product_name) values ('"+pid+"','"+product_name+"')",con);
        con.Open();
        cmd.ExecuteNonQuery();
        con.Close();
        TextBox1.Text = "";

        SqlCommand cmd1 = new SqlCommand("insert into stock_details(pid,product_name,kg)values ('"+pid+"','"+product_name+"','"+temp_kg+"')",con);
        con.Open();
        cmd1.ExecuteNonQuery();
        Page.RegisterStartupScript("msg", "<script>alert('New Item Stored')</script>");
        con.Close();

        Response.Redirect("supplier details.aspx");


    }
}
