﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;

public partial class bill : System.Web.UI.Page
{

    SqlConnection con = new SqlConnection("Data Source=.\\SQLEXPRESS; Initial Catalog=fruit_shop; integrated Security=true;");
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
        // this is for bill-no
        SqlDataAdapter ad = new SqlDataAdapter("select bill from bill_backup ", con);
        DataSet ds = new DataSet();
        ad.Fill(ds);

        string bill = ds.Tables[0].Rows[0][0].ToString();

        SqlDataAdapter ad1 = new SqlDataAdapter("select max(bill_no) from bill_backup ", con);
        DataSet ds1 = new DataSet();
        ad1.Fill(ds1);

        string no = ds1.Tables[0].Rows[0][0].ToString();

        string bill_no = string.Concat(bill,no);

        Label5.Text = bill_no;

        //this is for date 
        SqlDataAdapter ad3 = new SqlDataAdapter("select date from bill_backup",con);
        DataSet ds3 = new DataSet();
        ad3.Fill(ds3);

        Label7.Text = ds3.Tables[0].Rows[0][0].ToString();

        //grand_total

        SqlDataAdapter ad4 = new SqlDataAdapter("select sum(total) from bill_box", con);
        DataSet ds4 = new DataSet();
        ad4.Fill(ds4);
        Label9.Text = ds4.Tables[0].Rows[0][0].ToString();

        barcode_generate();

        }
       

    }
    public string getWhileLoopData()
    {
        string htmlStr = "";


        SqlCommand thisCommand = con.CreateCommand();
        thisCommand.CommandText = "SELECT * from bill_box";
        con.Open();
        SqlDataReader reader = thisCommand.ExecuteReader();

        while (reader.Read())
        {

            //  Debug.Indent(); Debug.WriteLine(reader.GetValue(0));

            // int pid =  reader.GetInt32(0);
            int pid = Convert.ToInt16(reader.GetValue(0));

            string product_name = reader.GetString(1);
            int quantity = reader.GetInt32(2);
            int rate = reader.GetInt32(3);
            int total = Convert.ToInt16(reader.GetValue(4));
            htmlStr += "<tr><td>" + pid + "</td><td>" + product_name + "</td><td>" + quantity + "</td><td>" + rate + "</td><td>" + total + "</td></tr>";
            
        }

       
        return htmlStr;
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlDataAdapter sad = new SqlDataAdapter("truncate table bill_box",con);
        DataSet sds = new DataSet();
        sad.Fill(sds);

        Response.Redirect("home.aspx");
    }

    public void barcode_generate()
    {
        SqlDataAdapter ad3 = new SqlDataAdapter("select sum(total)from bill_box", con);
        DataSet ds3 = new DataSet();
        ad3.Fill(ds3);

        string barCode =ds3.Tables[0].Rows[0][0].ToString();
        System.Web.UI.WebControls.Image imgBarCode = new System.Web.UI.WebControls.Image();
        using (Bitmap bitMap = new Bitmap(barCode.Length * 40, 80))
        {
            using (Graphics graphics = Graphics.FromImage(bitMap))
            {
                Font oFont = new Font("IDAutomationHC39M", 16);
                PointF point = new PointF(2f, 2f);
                SolidBrush blackBrush = new SolidBrush(Color.Black);
                SolidBrush whiteBrush = new SolidBrush(Color.White);
                graphics.FillRectangle(whiteBrush, 0, 0, bitMap.Width, bitMap.Height);
                graphics.DrawString("*" + barCode + "*", oFont, blackBrush, point);
            }
            using (MemoryStream ms = new MemoryStream())
            {
                bitMap.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
                byte[] byteImage = ms.ToArray();

                Convert.ToBase64String(byteImage);
                imgBarCode.ImageUrl = "data:image/png;base64," + Convert.ToBase64String(byteImage);
            }
            PlaceHolder1.Controls.Add(imgBarCode);
        }
    }
}